# Dervied class NearFieldAnalyzer from ImageAnalyzer for PyGEECSPlotter
# Author: Alex Picksley
# Version 0.4
# Created: 2024-02-26
# Last Modified: 2025-02-19


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import medfilt2d
from scipy.ndimage import affine_transform
from scipy.optimize import least_squares
import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning, message="Mean of empty slice")

import PyGEECSPlotter.ni_imread as ni_imread

from PyGEECSPlotter.image_analysis import ImageAnalyzer

class NearFieldAnalyzer(ImageAnalyzer):
    """
    Base class for image analysis. 
    Derive from this class to customize analysis steps for specific image types.
    """