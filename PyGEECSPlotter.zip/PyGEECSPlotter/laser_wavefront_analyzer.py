# Dervied class WavefrontAnalyzer from ImageAnalyzer for PyGEECSPlotter
# Author: Alex Picksley
# Version 0.4
# Created: 2024-02-26
# Last Modified: 2025-02-19

import numpy as np

import sys, os
sys.path.append('./../..')
import wavekit_py as wkpy
import time 
import ctypes

from PyGEECSPlotter.utils import merge_dicts_overwrite
from PyGEECSPlotter.wavefront_analysis import WavefrontAnalyzer


class LaserWavefrontAnalyzer(WavefrontAnalyzer):
    """
    Class for wavefront analysis. 
    """

    def __init__(self, 
        config_file_path=None, 
        start_subpupil_size=(20, 20), 
        denoising_strength=0.0
        ):
    
        super().__init__(config_file_path, start_subpupil_size, denoising_strength)

    # -------------------------------------------------------------------
    # Public pipeline method
    # -------------------------------------------------------------------

    def analyze_data(self, data, analyzer_dict={}, bg=None):
        hasoslopes = data
        hasodata = wkpy.HasoData(hasoslopes = hasoslopes)

        # Get pupil_method with a default fallback
        pupil_method = analyzer_dict.get("pupil_method", "auto")

        if pupil_method == "auto":
            # print("[INFO] Using 'auto' pupil detection: recalculating pupil for each shot.")
            self.pupil, self.pupil_dict = self.get_pupil(hasoslopes)

        elif pupil_method == "auto_first_shot":
            if self.pupil is None or self.pupil_dict is None:
                # print("[INFO] Using 'auto_first_shot': calculating pupil from first shot and reusing it.")
                self.pupil, self.pupil_dict = self.get_pupil(hasoslopes)
            # else:
                # print("[INFO] Reusing previously computed pupil from first shot.")

        elif pupil_method == "manual":
            if "manual_pupil_dict" in analyzer_dict:
                # print("[INFO] Using 'manual' pupil detection with user-provided parameters.")
                self.pupil_dict = analyzer_dict["manual_pupil_dict"]
                self.pupil = None  # No auto-detection when manually set
            else:
                print("[WARNING] 'manual' pupil method selected but no 'manual_pupil_dict' provided. Defaulting to 'auto'.")
                self.pupil, self.pupil_dict = self.get_pupil(hasoslopes)

        else:
            print(f"[WARNING] Invalid pupil_method '{pupil_method}'. Defaulting to 'auto'.")
            self.pupil, self.pupil_dict = self.get_pupil(hasoslopes)

        pupil_center = wkpy.float2D(self.pupil_dict['pupil_center_x'], self.pupil_dict['pupil_center_y'])
        pupil_radius = self.pupil_dict['pupil_radius']
            

        if analyzer_dict.get('filter_tilts_and_curv', False):
            phasemap_aberration_filter = [0,0,0,1,1]
        else:
            phasemap_aberration_filter = [1,1,1,1,1]
            

        zernike_data, zernike_pupil, zernike_dict, zernike_phase_statistics = self.zernike_reconstruction(hasoslopes, 
                                   hasodata, 
                                   pupil_center,
                                   pupil_radius,
                                   nb_modes=analyzer_dict.get('nb_modes', 32),
                                   coefs_to_filter=analyzer_dict.get('zernike_coefs_to_filter', []),
                                   phasemap_aberration_filter=phasemap_aberration_filter,
                                   nan_to_zero=analyzer_dict.get('set_nan_to_zero', False)
                                  )
        geometric_properties = LaserWavefrontAnalyzer.slopes_geometric_properties(hasoslopes)
        zonal_data, zonal_pupil, zonal_phase_statistics = self.zonal_reconstruction(hasodata, 
                                                                               phasemap_aberration_filter=phasemap_aberration_filter[:-2],
                                                                               nan_to_zero=analyzer_dict.get('set_nan_to_zero', False)
                                                                              )

        results = self.compute_phase_shifts(zonal_data, shifts_when='')

        if analyzer_dict.get('outlier_threshold', None) is not None:
            zonal_data = self.remove_outliers(zonal_data, threshold=3)
            results.update( self.compute_phase_shifts(zonal_data, shifts_when='outliers removed') )
            
        return_dict = merge_dicts_overwrite(self.pupil_dict, 
                                            zernike_dict, 
                                            zernike_phase_statistics, 
                                            geometric_properties, 
                                            zonal_phase_statistics, 
                                            results
                                            )

        if analyzer_dict.get('reconstruct_intensity', False):
            intensity = LaserWavefrontAnalyzer.intensity_reconstruction(hasoslopes)
            return_dict['intensity'] = intensity


        return zonal_data, return_dict
    

    # -------------------------------------------------------------------
    # Utility methods (can be overridden or extended in subclasses)
    # -------------------------------------------------------------------

    def zernike_reconstruction(self, 
                               hasoslopes, 
                               hasodata,
                               pupil_center,
                               pupil_radius,
                               nb_modes=32,
                               coefs_to_filter=[],
                               phasemap_aberration_filter=[1,1,1,1,1],
                               nan_to_zero=False
                              ):
        
        modal_coef = wkpy.ModalCoef(modal_type = wkpy.E_MODAL.ZERNIKE)
        modal_coef.set_zernike_prefs(
            wkpy.E_ZERNIKE_NORM.STD,
            nb_modes,
            coefs_to_filter,
            wkpy.ZernikePupil_t(
                pupil_center,
                pupil_radius
                ),
        )

        wkpy.Compute.coef_from_hasodata(self.compute_phase_set_zernike, hasodata, modal_coef)

        size = modal_coef.get_dim()
        data_coeffs, data_indexes, pupil = modal_coef.get_data()

        phase = wkpy.Phase(
                hasoslopes=hasoslopes,  # Pass the HasoSlopes object
                type_=2,                # Set type_ to 2 for Zernike reconstruction
                filter_=phasemap_aberration_filter,        # Aberration filter list
                nb_coeffs=nb_modes     # Number of Zernike coefficients
            )
        data, pupil = phase.get_data()
        if nan_to_zero:
            data[np.isnan(data)] = 0.0

        zernike_dict = {f'zernike_{index}': coeff for index, coeff in zip(data_indexes, data_coeffs)}

        names = ['tilt_0', 'tilt_90', 'focus', 'astig_0', 'astig_45', 'coma_0', 'coma_90', 'spherical', 'trefoil_0', 'trefoil_90',
                '5th_astig_0', '5th_astig_45', '5th_coma_0', '5th_coma_90', '5th_spherical', 'tetrafoil_0', 'tetrafoil_45']
        named_indexes = list(range(1, len(names) + 1))

        zernike_dict = {
            (f'zernike_{i:02d}_{names[i - 1]} (um)' if i in named_indexes else f'zernike_{i:02d} (um)'): coeff
            for i, coeff in zip(data_indexes, data_coeffs)
        }

        zernike_phase_statistics = {
            'zernike_phase_rms (um)' : phase.get_statistics().rms,
            'zernike_phase_pv (um)' : phase.get_statistics().pv,
            'zernike_phase_max (um)' : phase.get_statistics().max,
            'zernike_phase_min (um)' : phase.get_statistics().min,
        }
        
        return data, pupil, zernike_dict, zernike_phase_statistics

    def zonal_reconstruction(self, hasodata, phasemap_aberration_filter=[1, 1, 1], nan_to_zero=False):
        self.compute_phase_set_zonal.set_zonal_filter(phasemap_aberration_filter)
        phase = wkpy.Compute.phase_zonal(compute_phase_set=self.compute_phase_set_zonal, hasodata=hasodata)
        data, pupil = phase.get_data()
        if nan_to_zero:
            data[np.isnan(data)] = 0.0
        zonal_phase_statistics = {
            'zonal_phase_rms (um)' : phase.get_statistics().rms,
            'zonal_phase_pv (um)' : phase.get_statistics().pv,
            'zonal_phase_max (um)' : phase.get_statistics().max,
            'zonal_phase_min (um)' : phase.get_statistics().min,
        }
        return data, pupil, zonal_phase_statistics
    
    @staticmethod
    def get_pupil(hasoslopes):
        pupil = wkpy.Pupil(hasoslopes = hasoslopes)
        center, radius = wkpy.ComputePupil.fit_zernike_pupil(
            pupil,
            wkpy.E_PUPIL_DETECTION.AUTOMATIC,
            wkpy.E_PUPIL_COVERING.INSCRIBED,
            False)

        pupil_dict = {
            'pupil_center_x' : center.X,
            'pupil_center_y' : center.Y,
            'pupil_radius' : radius,
        }
        
        return pupil, pupil_dict

    @staticmethod
    def slopes_geometric_properties(hasoslopes):
        properties = hasoslopes.get_geometric_properties()
        geometric_properties = {
            'geometric_tilt_x (mrad)' : properties[0], 
            'geometric_tilt_y (mrad)': properties[1],
            'geometric_radius (mm)' : properties[2],
            'geometric_focus_x_pos (mm)' : properties[3],
            'geometric_focus_y_pos (mm)' : properties[4],
            'geometric_astig_angle (rad)' : properties[5],
            'geometric_sagittal (mm)' : properties[6],
            'geometric_tangential (mm)' : properties[7],
            'geometric_curvature (per m)' : 1.0/(properties[2]*1e-3)
        }
        return geometric_properties

    @staticmethod
    def intensity_reconstruction(hasoslopes):
        return hasoslopes.get_intensity()