# PyGEECS base functions
# Author: Alex Picksley
# Version 0.3
# Created: 2024-02-26
# Last Modified: 2024-10-30

import numpy as np
import os, sys
import re
import glob
import json
import datetime
import pandas as pd
from pathlib import Path
import ipywidgets as widgets
from IPython.display import display
import imageio as imio

####
import matplotlib.pyplot as plt
import PyGEECSPlotter.bin_data as bin_data
####

print('PyGEECSPlot imported successfully...')

def get_local_repo_dir(repo='BELLA-Analysis-Tools') -> str:
    """Finds and returns the base directory for BELLA-Analysis-Tools as a string."""
    
    # Check all sys.path entries for potential locations
    for path in sys.path:
        candidate = Path(path).resolve()
        if repo in candidate.parts:
            idx = candidate.parts.index(repo)
            return str(Path(*candidate.parts[:idx + 1]))  # Return path up to BELLA-Analysis-Tools

    # Fallback to searching from the script or current working directory
    try:
        script_dir = Path(__file__).resolve()  # Works in scripts
    except NameError:
        script_dir = Path.cwd().resolve()  # Fallback for interactive environments

    for parent in script_dir.parents:
        if parent.name == repo:
            return str(parent)  # Return only up to BELLA-Analysis-Tools

    raise FileNotFoundError(f"{repo} directory not found. Check your working directory or import path.")



# Functions to get sfile data

def _format_date(year, month, day):
    datetime_object = datetime.datetime.strptime('%d' % month, '%m')
    month_name = datetime_object.strftime('%b')
    return '%02d-%s' % (month, month_name)

def get_top_dir(experiment_dir, year, month, day, print_data=True):
    formatted_month = _format_date(year, month, day)
    top_dir = os.path.join(experiment_dir, 'Y%d' %year, '%s' %formatted_month ,'%d_%02d%02d' %(year-2000, month, day))
    
    if print_data:
        print('Top Dir                  : %s' %top_dir)
        
    return top_dir
    
def get_top_dir_from_sfilename(sfilename, print_data=True):
    date_part = re.search(r'(\d{2}_\d{4})', sfilename)
    
    if not date_part:
        raise ValueError("Date part not found in the filename.")
    
    date_part = date_part.group(1)
    
    # Parse the date part to get year, month, day
    yy_mmdd = datetime.datetime.strptime(date_part, '%y_%m%d')
    
    year = yy_mmdd.year
    month = yy_mmdd.month
    day = yy_mmdd.day
    
    # Get the top directory up to 'analysis'
    path_parts = sfilename.split(os.sep)
    try:
        analysis_index = path_parts.index('analysis')
    except ValueError:
        raise ValueError("'analysis' directory not found in the file path.")
    
    top_dir = os.sep.join(path_parts[:analysis_index])

    if print_data:
        print('Top Dir                  : %s' %top_dir)
    
    return top_dir, year, month, day
    
def get_sfilename_from_top_dir(top_dir, scan, print_data=True):
    sfilename = os.path.join(top_dir, 'analysis', 's%d.txt' %scan)
    if print_data:
        print('sfilename                  : %s' %sfilename)
        
    return sfilename

def get_todays_top_dir(experiment_dir):
    # Get today's date
    today = pd.date_range(start=datetime.date.today(), periods=1).strftime('%Y%m%d').tolist()[0]
    
    # Extract year, month, and day
    year = int(today[0:4])
    month = int(today[4:6])
    day = int(today[6:8])
    
    # Get month name abbreviation
    formatted_month = _format_date(year, month, day)
    
    # Construct the directory path
    top_dir = os.path.join(
        experiment_dir, 
        f'Y{year}', 
        f'{formatted_month}', 
        f'{year - 2000}_{month:02d}{day:02d}'
    )
    
    return top_dir

def get_shot_num(filename):
    """
    Extracts the last number from a given filename string.
    
    Parameters:
        filename (str): The input filename string.
        
    Returns:
        int: The last number found in the filename.
             Returns None if no number is found.
    """
    numbers = re.findall(r'\d+', filename)
    if numbers:
        return int(numbers[-1])
    else:
        return None  # Return None if no number is found

def generate_title(year, month, day, sfilename=None, diagnostic='', title_append=''):
    parts = []

    if diagnostic:
        parts.append(diagnostic)

    parts.append(f"{year - 2000}_{month:02d}{day:02d}")

    if sfilename:
        parts.append(os.path.basename(sfilename))

    if title_append:
        parts.append(title_append)

    return ' - '.join(parts)

def generate_sfilename_list(top_dir, all_sfiles=True, scan_start=0, scan_end=500, remove_masterlog=True, check_non_empty=True):
    sfilename_list = []
    
    if all_sfiles:
        sfilename_list = sorted(glob.glob(os.path.join(top_dir, 'analysis', '*.txt')))
        sfilename_list = [item for item in sfilename_list if "info.txt" not in item]
        if remove_masterlog:
            sfilename_list = [item for item in sfilename_list if "masterlog-t" not in item]
    
    else:
        for scan in range(scan_start, scan_end):
            sfilename = os.path.join(top_dir, 'analysis', 's%d.txt' % scan)
            if os.path.exists(sfilename):
                sfilename_list.append(sfilename)
    
    if check_non_empty:
        valid_sfilename_list = []
        for sfilename in sfilename_list:
            try:
                sfile_data = pd.read_csv(sfilename, sep='\t')
                if len(sfile_data) > 0:
                    valid_sfilename_list.append(sfilename)
            except Exception as e:
                print(f"Error reading {sfilename}: {e}")
        return valid_sfilename_list
    
    return sfilename_list


# sfile data read in
def read_sfile(sfilename):
    return pd.read_csv(sfilename, sep='\t')

def load_scan_data(top_dir, sfilename, 
    search_replace_filename=None, 
    column_math_filename=None, 
    parse_from='python', 
    diagnostic=None,
    file_ext=None,
    remove_missing_diagnostic_files=True,
    print_data=False
    ):

    sfile_data = read_sfile(sfilename)
    if len(sfile_data) == 0:
        return sfile_data, 'Shotnumber', np.nan
    
    else:
        scan_parameter, scan = get_scan_parameter(top_dir, sfile_data)
        scan_data = sfile_data.copy()
        for col in scan_data.columns:
            scan_data.rename(columns={col: get_parameter_alias(col)}, inplace=True)
        
        scan_data['temp Bin number'] = scan_data['Bin #']
        
        if search_replace_filename is not None:
            scan_data = add_search_replace_column_names(search_replace_filename, scan_data, parse_from=parse_from, print_data=print_data)
            scan_parameter = add_search_replace_scan_parameter(search_replace_filename, scan_parameter, parse_from=parse_from, print_data=print_data)
        if column_math_filename is not None:
            scan_data = add_column_math(column_math_filename, scan_data, parse_from=parse_from, print_data=print_data)
        if diagnostic is not None and file_ext is not None:
            scan_data = add_file_list_to_scan_data(top_dir, scan_data, diagnostic, file_ext, 
                remove_missing_files=remove_missing_diagnostic_files, print_data=print_data)

        return scan_data, scan_parameter, scan
        
def merge_scan_data(top_dir, sfilename_list, search_replace_filename=None, column_math_filename=None, diagnostic=None, file_ext=None):
    merged_data = pd.DataFrame()  # Initialize an empty DataFrame to store merged data
    
    for sfilename in sfilename_list:
        scan_data, scan_parameter, scan = load_scan_data(
            top_dir, sfilename, 
            search_replace_filename=search_replace_filename, 
            column_math_filename=column_math_filename, 
            diagnostic=diagnostic, 
            file_ext=file_ext
            
        )
        # Append the scan data to the merged DataFrame
        merged_data = pd.concat([merged_data, scan_data], ignore_index=True)
    
    return merged_data, scan_parameter, scan


def add_file_list_to_scan_data(top_dir, scan_data, diagnostic, file_ext, remove_missing_files=True, print_data=True):
    """
    Generate file paths from scan data for a specified diagnostic and check for their existence.

    This function constructs file paths based on scan numbers and shot numbers from the provided scan data, appending a specified file extension. It supports looking up directories for both raw data and analysis results. The function also verifies the existence of each file and optionally prints the total number of files to be analyzed.

    If no directory is found for the specified diagnostic, the function returns the original `scan_data` DataFrame with two additional columns for the diagnostic's file list and existence status, both set to default values (empty strings and 0, respectively).

    Parameters:
    - top_dir (str): The top-level directory under which scan data directories are organized.
    - scan_data (pd.DataFrame or similar): A data structure containing 'scan' and 'Shotnumber' columns.
    - diagnostic (str): The name of the diagnostic to construct file paths for.
    - file_ext (str): The file extension to append to each generated file path.
    - print_data (bool, optional): If True, prints the number of files to be analyzed and any missing files. Defaults to True.

    Returns:
    - scan_data (pd.DataFrame or similar): The updated scan data structure with two new columns:
        - '<diagnostic> file_list': A list of constructed file paths.
        - '<diagnostic> file_exists': A list indicating the existence of each file path in the corresponding file list.
    """

    scan = scan_data['scan'][0]
    if os.path.exists( os.path.join(top_dir, 'scans', 'Scan%03d' %scan, diagnostic) ):
        diagnostic_dir = os.path.join(top_dir, 'scans', 'Scan%03d' %scan, diagnostic)
        analysis_diagnostic = False
    elif os.path.exists( os.path.join(top_dir, 'analysis', 'Scan%03d' %scan, diagnostic) ):
        diagnostic_dir = os.path.join(top_dir, 'analysis', 'Scan%03d' %scan, diagnostic)
        analysis_diagnostic = True
    else:
        print('No directory found')
        
        scan_data['%s file_list' %diagnostic] = ''
        scan_data['%s file_exists' %diagnostic] = 0
        
        if remove_missing_files:
            scan_data = scan_data[scan_data['%s file_exists' %diagnostic] != 0].reset_index(drop=True)
            if print_data:
                n_missing = np.sum(1 - np.array(file_exists))
                print('Removed %d lines from scan_data for missing files' %n_missing)
            
        return scan_data

    file_list = []
    file_exists = []
    for i in range(len(scan_data)):
        scan = scan_data['scan'][i]
        shot_num = scan_data['Shotnumber'][i]
        
        if analysis_diagnostic:
            diagnostic_dir = os.path.join(top_dir, 'analysis', 'Scan%03d' %scan, diagnostic)
        else:
            diagnostic_dir = os.path.join(top_dir, 'scans', 'Scan%03d' %scan, diagnostic)

        basename = r'Scan%03d_%s_%03d%s' %(scan, diagnostic, shot_num, file_ext)
        filename = os.path.join(diagnostic_dir, basename)
        
        file_list.append( filename )
        file_exists.append( os.path.exists( filename ) )    

        if not os.path.exists( filename ) and print_data:
            print('Did not save : %s' %os.path.basename(filename))

    if print_data:
        print('Files to analyse : %d' %len(file_list) )
        
    scan_data['%s file_list' %diagnostic] = file_list
    scan_data['%s file_exists' %diagnostic] = file_exists
    
    if remove_missing_files:
        scan_data = scan_data[scan_data['%s file_exists' %diagnostic] != 0].reset_index(drop=True)
        if print_data:
            n_missing = np.sum(1 - np.array(file_exists))
            print('Removed %d lines from scan_data for missing files' %n_missing)

    return scan_data 

def get_scan_info_text(top_dir, scan, print_data=True):
    with open(os.path.join(top_dir, 'scans', 'Scan%03d' %scan, 'ScanInfoScan%03d.ini' %scan)) as f:
        lines = f.readlines()
    scan_info_text = lines[2].split('"')[1]
    
    if print_data:
        print('Scan Information  : %s' %scan_info_text)
    return scan_info_text

    
def scan_parameter_with_alias(scan_parameter, scan_data):
    if scan_parameter in scan_data.columns:
        return scan_parameter
    elif len([i for i in scan_data.columns if '%s Alias:' %scan_parameter in i]) == 1:
        return [i for i in scan_data.columns if '%s Alias:' %scan_parameter in i][0]
    else:
        print('Could not find scan_parameter %s' %scan_parameter)
        return scan_parameter
    
def get_param_list_no_alias(param_list):
    param_list_no_alias = []
    for param in param_list:
        param_list_no_alias.append( param.split(' Alias:')[0] )
    return param_list_no_alias

def get_param_list_alias(param_list):
    param_list_alias = []
    for param in param_list:
        param_list_alias.append( param.split(' Alias:')[-1] )
    return param_list_alias

def get_parameter_no_alias(parameter):
    return parameter.split(' Alias:')[0]

def get_parameter_alias(parameter):
    return parameter.split(' Alias:')[-1]

def get_scan_parameter(top_dir, sfile_data):
    scan = sfile_data['scan'][0]
    file_path = os.path.join(top_dir, 'scans', 'Scan%03d' % scan, 'ScanInfoScan%03d.ini' % scan)
    with open(file_path, 'r') as f:
        lines = f.readlines()
    scan_parameter_full = scan_parameter_with_alias(lines[3].split('"')[1], sfile_data)
    scan_parameter = get_parameter_alias(scan_parameter_full)
    return scan_parameter, scan
    
def get_analysis_dir(top_dir, scan, save_label=None, make_dir=False, print_data=True):
    if save_label is None:
        analysis_dir = os.path.join(top_dir, 'analysis', 'Scan%03d' %scan)
    else:
        analysis_dir = os.path.join(top_dir, 'analysis', save_label, 'Scan%03d' %scan)
    if make_dir and not os.path.exists(analysis_dir):
        os.makedirs(analysis_dir)
    if print_data:
        print('Analysys Dir             : %s' %analysis_dir)
    return analysis_dir
    
def get_analysed_shot_save_path(analysis_dir, analysis_diagnostic, scan, shot_num, file_ext='.txt'):
    # Construct the basename with the specified format and file extension
    basename = f'Scan{scan:03d}_{analysis_diagnostic}_{shot_num:03d}{file_ext}'
    
    # Construct the full save path
    save_path = os.path.join(analysis_dir, analysis_diagnostic, basename)
    
    # Ensure the directory exists
    dir_path = os.path.join(analysis_dir, analysis_diagnostic)
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    
    return save_path

def get_scan_data_columns(scan_data, filter_str='', print_data=True):
    column_idcs = []
    for c in range(len(scan_data.columns)):
        if filter_str in scan_data.columns[c]:
            column_idcs.append(c)
            if print_data:
                print('%d : %s' %(c, scan_data.columns[c]))
    print('')
    return column_idcs

def filter_scan_data(scan_data, filter_parameter, lower_bound, upper_bound, filter_exclusive=False, print_data=True):
    """
    Filter scan data based on a specified parameter and value range.

    This function filters rows in a DataFrame based on whether the values of a specified parameter fall within (inclusive or exclusive) a given range. Optionally, it can print the count of rows that were included after filtering relative to the total count.

    Parameters:
    - scan_data (pd.DataFrame): A pandas DataFrame containing the scan data to be filtered.
    - filter_parameter (str): The column name in `scan_data` to apply the filter on.
    - lower_bound (float): The lower bound of the filtering range.
    - upper_bound (float): The upper bound of the filtering range.
    - filter_exclusive (bool, optional): If True, rows with `filter_parameter` values outside the [lower_bound, upper_bound] range are included. If False, only rows with `filter_parameter` values inside this range are included. Defaults to False.
    - print_data (bool, optional): If True, prints the number of shots included after filtering and the total number of shots, along with the parameter used for filtering. Defaults to True.

    Returns:
    - filtered_scan_data (pd.DataFrame): A DataFrame containing only the rows that meet the filtering criteria.

    The function supports both inclusive and exclusive filtering and provides an option to visualize the filtering impact through printed output.
    """
    
    if filter_exclusive:
        filter_idcs = (scan_data[filter_parameter] < lower_bound) | (scan_data[filter_parameter] >  upper_bound)
    else:
        filter_idcs = (scan_data[filter_parameter] > lower_bound) & (scan_data[filter_parameter] <  upper_bound)

    filtered_scan_data = scan_data.loc[filter_idcs].reset_index(drop=True)
    
    if print_data:
        print('%d / %d shots included. Filtered based on : %s ' %(len(filtered_scan_data), len(scan_data), get_parameter_alias(filter_parameter)))
        
    return filtered_scan_data
    
# Column math and column name search and replace
def parse_column_math_from_lv_controls(file_path):
    clusters = []
    current_cluster = {}
    variables = []

    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            if line.startswith('Value') and '.Cluster.New (or old) column name' in line:
                if current_cluster:
                    current_cluster['variables'] = variables
                    clusters.append(current_cluster)
                    variables = []
                current_cluster = {'column_name': line.split('=')[1].strip()}
            elif line.startswith('Value') and '.Cluster.Formula' in line:
                current_cluster['formula'] = line.split('=')[1].strip()
            elif '.Cluster.vars' in line and '.Cluster.Column name' in line:
                # This is not expected to happen as per the provided format,
                # it seems to be a misunderstanding of the format.
                pass
            elif '.Cluster.vars' in line or '.Cluster.Column name' in line:
                var_name = line.split('=')[1].strip()
                var_key = 'vars' if '.Cluster.vars' in line else 'column_name'
                if variables and var_key in variables[-1]:
                    # If the last variable already has this key, start a new variable
                    variables.append({var_key: var_name})
                elif variables:
                    variables[-1][var_key] = var_name
                else:
                    variables.append({var_key: var_name})

        # Add the last cluster if it exists
        if current_cluster:
            current_cluster['variables'] = variables
            clusters.append(current_cluster)

    return clusters


def parse_search_replace_from_lv_controls(file_path):
    search_replace_pairs = []
    
    with open(file_path, 'r') as file:
        text_content = file.read()

    lines = text_content.strip().split('\n')
    for line in lines:
        if 'Cluster.Search=' in line:
            search_term = line.split('=')[1]
            if "Bella" in search_term:
                continue
            replace_term = next((l.split('=')[1] for l in lines if l.startswith(line.split('.Search')[0] + '.Replace=')), '')
            search_replace_pairs.append({'Search': search_term, 'Replace': replace_term})

    return search_replace_pairs
    
def convert_to_serializable(obj):
    if isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, list):
        return [convert_to_serializable(item) for item in obj]
    elif isinstance(obj, dict):
        return {key: convert_to_serializable(value) for key, value in obj.items()}
    else:
        return obj
        
def write_controls_from_python(filename, controls_dict, print_data=False):
    controls_dict_serializable = convert_to_serializable(controls_dict)
    with open(filename, 'w') as file:
        json.dump(controls_dict_serializable, file, indent=4)
    if print_data:
        print(f'Controls saved to : {filename}')

def parse_controls_from_python(filename):
    with open(filename, 'r') as file:
        controls_dict = json.load(file)
    return controls_dict

def execute_search_replace_column_names(search_replace_pairs, scan_data):
    for col in scan_data.columns:
        new_col_name = col
        for pair in search_replace_pairs:
            new_col_name = new_col_name.replace(pair['Search'], pair['Replace'])
        scan_data.rename(columns={col: new_col_name}, inplace=True)
    return scan_data
    
def execute_search_replace_scan_parameter(search_replace_pairs, scan_parameter):
    new_scan_parameter = scan_parameter 
    for pair in search_replace_pairs:
        new_scan_parameter = new_scan_parameter.replace(pair['Search'], pair['Replace'])
    return new_scan_parameter

def add_column_math(column_math_filename, scan_data, parse_from='labview', print_data=False):
    if parse_from == 'labview':
        math_clusters_list = parse_column_math_from_lv_controls(column_math_filename)
    elif parse_from == 'python':
        math_clusters_list = parse_controls_from_python(column_math_filename)
    else:
        print("parse_from options 'labview' or 'python'. No column math added")
        return scan_data
    
    for math_cluster in math_clusters_list:
        scan_data = execute_column_math(math_cluster, scan_data, print_data=print_data)
    
    return scan_data

def execute_column_math(math_cluster, scan_data, print_data=False):
    column_name = math_cluster['column_name']
    var_exists = []
    for variable in math_cluster['variables']:
        var_exists.append( variable['column_name'] in scan_data.columns )
    if all(var_exists):
        formula = math_cluster['formula']
        formula = formula.replace('^', '**')
        for func in ["sqrt", "exp", "sin", "cos", "abs", "min", "max"]:
            formula = formula.replace(func, f"np.{func}")

        for variable in math_cluster['variables']:
            exec( "%s = scan_data['%s']" %(variable['vars'], variable['column_name']) )
        result = eval(formula)
        scan_data[column_name] = result
    else:
        if print_data:
            print('Column %s not added, variables not in s-file ' %column_name)
                
    return scan_data

def add_search_replace_column_names(search_replace_filename, scan_data, parse_from='labview', print_data=False):
    if parse_from == 'labview':
        search_replace_pairs = parse_search_replace_from_lv_controls(search_replace_filename)
    elif parse_from == 'python':
        search_replace_pairs = parse_controls_from_python(search_replace_filename)
    else:
        print("parse_from options 'labview' or 'python'. No search and replace done")
        return scan_data
    
    scan_data = execute_search_replace_column_names(search_replace_pairs, scan_data)
    
    return scan_data
    
def add_search_replace_scan_parameter(search_replace_filename, scan_parameter, parse_from='labview', print_data=False):
    if parse_from == 'labview':
        search_replace_pairs = parse_search_replace_from_lv_controls(search_replace_filename)
    elif parse_from == 'python':
        search_replace_pairs = parse_controls_from_python(search_replace_filename)
    else:
        print("parse_from options 'labview' or 'python'. No search and replace done")
        return scan_parameter
    
    scan_parameter = execute_search_replace_scan_parameter(search_replace_pairs, scan_parameter)
    
    return scan_parameter
    


    
def get_bg_file_path(top_dir, diagnostic, which_scan='last', print_data=True):
    """
    Retrieves the background file path for a specific diagnostic from the analysis directory.

    This function searches for the background file based on the specified scan. It can retrieve
    the first, last, a specific scan's background file, or a file matching a given string.
    The file is expected to have the naming pattern '*<diagnostic>_averaged.png' within the 'analysis' directory.

    Parameters:
    - top_dir (str): The top-level directory where the analysis directory is located.
    - diagnostic (str): The name of the diagnostic to search for.
    - which_scan (str or int, optional): Specifies which scan to retrieve:
        - 'first': Retrieves the first matching file.
        - 'last': Retrieves the last matching file.
        - int: Retrieves the file for the specific scan number.
        - str: Searches for a file that includes the string in its name.
        Defaults to 'last'.
    - print_data (bool, optional): If True, prints the file path found. Defaults to True.

    Returns:
    - bg_file_path (str or int): The path to the background file, or 0 if no file is found or an error occurs.
    """
    try:
        # Retrieve all matching files
        bg_file_paths = glob.glob(os.path.join(top_dir, 'analysis', '*%s_averaged.png' % diagnostic))
        
        if not bg_file_paths:
            print(f"No background files found for diagnostic '{diagnostic}'.")
            return None

        if which_scan == 'first':
            bg_file_path = bg_file_paths[0]
        elif which_scan == 'last':
            bg_file_path = bg_file_paths[-1]
        elif isinstance(which_scan, int):
            scan_paths = glob.glob(os.path.join(top_dir, 'analysis', '*Scan%03d%s_averaged.png' % (which_scan, diagnostic)))       
            if len(scan_paths) == 1:
                bg_file_path = scan_paths[-1]
            else:
                print(f"No background file found for Scan {which_scan} with diagnostic '{diagnostic}'.")
                return None
        elif isinstance(which_scan, str):
            # Find the file that contains the specified string
            matching_files = [path for path in bg_file_paths if which_scan in os.path.basename(path)]
            if matching_files:
                bg_file_path = matching_files[0]  # You could return the first match or handle multiple matches differently
            else:
                print(f"No background file found matching '{which_scan}' for diagnostic '{diagnostic}'.")
                return None
        else:
            print("Invalid value for 'which_scan'. Must be 'first', 'last', an integer, or a string.")
            return None

        if print_data:
            print(f"Bg File Path             : {bg_file_path}")
        
        return bg_file_path
    
    except IndexError:
        print(f"No background file found for diagnostic '{diagnostic}'.")
        return None
    except Exception as e:
        print(f"An error occurred while retrieving the background file path: {e}")
        return None


    
####
# statistics

def get_parameter_statistics(scan_data, parameter, method='std_dev'):
    """
    Get binned statistics for a given parameter in the s-file
    
    Parameters:
    - scan_data (DataFrame): s-file as a pandas DataFrame
    - parameter (str): The key in `scan_data` for which to calculate statistics.
    - method (str, optional): The method to use for calculating error margins. Options are 'std_dev', 'std_err', 'quarter_pct', or 'max'. Default is 'std_dev'.

    Returns:
    - p_av (np.ndarray): An array of average values for each bin.
    - p_neg (np.ndarray): An array of negative error margins for each bin.
    - p_pos (np.ndarray): An array of positive error margins for each bin.

    The function handles missing values (NaNs) gracefully in its computations.
    """
    p_av = []
    p_neg = []
    p_pos = []

    bin_nums = np.unique(scan_data['temp Bin number'])

    if method == 'std_dev':
        for b in range(len(bin_nums)):
            idcs = np.where(np.array(scan_data['temp Bin number']) == bin_nums[b])[0]
            p_av.append( np.nanmean( scan_data[parameter][idcs]) )
            p_neg.append( np.nanstd( scan_data[parameter][idcs]) )
            p_pos.append( np.nanstd( scan_data[parameter][idcs]) )
    elif method == 'std_err':
        for b in range(len(bin_nums)):
            idcs = np.where(np.array(scan_data['temp Bin number']) == bin_nums[b])[0]
            p_av.append( np.nanmean( scan_data[parameter][idcs]) )
            p_neg.append( np.nanstd( scan_data[parameter][idcs]) / np.sqrt(len(idcs)) )
            p_pos.append( np.nanstd( scan_data[parameter][idcs]) / np.sqrt(len(idcs)) )
    elif method == 'quarter_pct':
        for b in range(len(bin_nums)):
            idcs = np.where(np.array(scan_data['temp Bin number']) == bin_nums[b])[0]
            p_av.append( np.nanmedian( scan_data[parameter][idcs]) )
            p_neg.append( np.nanpercentile( scan_data[parameter][idcs], 50) - np.nanpercentile( scan_data[parameter][idcs], 25) )
            p_pos.append( np.nanpercentile( scan_data[parameter][idcs], 75) - np.nanpercentile( scan_data[parameter][idcs], 50) )        
    elif method == 'max':
        for b in range(len(bin_nums)):
            idcs = np.where(np.array(scan_data['temp Bin number']) == bin_nums[b])[0]
            p_av.append( np.nanmax( scan_data[parameter][idcs]) )
            p_neg.append( np.nanmax( scan_data[parameter][idcs]) - np.nanpercentile( scan_data[parameter][idcs], 25) )
            p_pos.append( 0 ) 

    p_av = np.asarray(p_av)
    p_neg = np.asarray(p_neg)
    p_pos = np.asarray(p_pos)
    
    return p_av, p_neg, p_pos


def get_parameter_list_statistics(scan_data, param_list, method='std_dev'):
    """
    Get binned statistics for a given list of parameters in the s-file
    
    Parameters:
    - scan_data (DataFrame): s-file as a pandas DataFrame
    - param_list (list): A list of parameter names (str) in `scan_data` for which to calculate statistics.
    - method (str): The method to use for calculating statistics, passed to `calculate_bin_statistics`. Options typically include 'std_dev', 'std_err', 'quarter_pct', or 'max'.

    Returns:
    - plist_av (list of np.ndarray): A list where each element is an array of average values for a parameter across bins.
    - plist_neg (list of np.ndarray): A list where each element is an array of negative error margins for a parameter across bins.
    - plist_pos (list of np.ndarray): A list where each element is an array of positive error margins for a parameter across bins.

    Note: The returned lists contain numpy arrays for each parameter specified in `param_list`, in the same order.
    """

    bin_nums = np.unique(scan_data['temp Bin number'])

    plist_av = []
    plist_neg = []
    plist_pos = []

    for parameter in param_list:
        p_av, p_neg, p_pos = get_parameter_statistics(scan_data, parameter, method=method)
        
        plist_av.append(p_av)
        plist_neg.append(p_neg)
        plist_pos.append(p_pos)  

    # Convert lists of arrays into numpy arrays for consistency in output format
    plist_av = np.asarray(plist_av)
    plist_neg = np.asarray(plist_neg)
    plist_pos = np.asarray(plist_pos)

    return plist_av, plist_neg, plist_pos
    
def process_parameter_vs_scan_parameter(scan_data, scan_parameter, parameter, analyzer_dict={}):
    # Check for manual scan parameter setting
    manual_scan_parameter = analyzer_dict.get('manual_scan_parameter', None)
    if manual_scan_parameter is not None:
        scan_data, scan_parameter, _ = set_scan_parameter(
            scan_data, 
            manual_scan_parameter, 
            rebin_data=analyzer_dict.get('rebin_data', False), 
            method=analyzer_dict.get('rebin_method', 'zscore'),
            zscore_thresh=analyzer_dict.get('rebin_zscore_thresh', 1), 
            rounding_factor=analyzer_dict.get('rebin_rounding_factor', 1)
        )
    
    # Apply filters if provided
    filters_list = analyzer_dict.get('filters_list', [])
    for filter_param in filters_list:
        param_name = filter_param.get('filter_parameter')
        lower_bound = filter_param.get('lower_bound', None)
        upper_bound = filter_param.get('upper_bound', None)
        exclusive = filter_param.get('filter_exclusive', False)
        
        if param_name is not None:
            scan_data = filter_scan_data(scan_data, param_name, lower_bound, upper_bound, filter_exclusive=exclusive)
    
    # Get parameter statistics
    average_method = analyzer_dict.get('average_method', 'std_dev')
    p_av, p_neg, p_pos = get_parameter_statistics(scan_data, parameter, method=average_method)
    xp_av, xp_neg, xp_pos = get_parameter_statistics(scan_data, scan_parameter, method=average_method)
    
    return (p_av, p_neg, p_pos, xp_av, xp_neg, xp_pos)

def multi_scan_scalar_parameter(top_dir, sfilename_list, parameter, 
                                compare_parameter=None,
                                search_replace_filename=None, 
                                column_math_filename=None, 
                                analyzer_dict={}):
    
    results = []
    compare_parameter_results = []
    sfilename_list = check_sfilename_list_contents(top_dir, sfilename_list)
    manual_scan_parameter = analyzer_dict.get('manual_scan_parameter', None)

    if analyzer_dict.get('temp_merge', False):
        scan_data, scan_parameter, scan = merge_scan_data(
            top_dir, sfilename_list, 
            search_replace_filename=search_replace_filename, 
            column_math_filename=column_math_filename
        )
        results.append( process_parameter_vs_scan_parameter(scan_data, scan_parameter, parameter, analyzer_dict) )
        compare_parameter_results = ", ".join([os.path.basename(sfilename) for sfilename in sfilename_list])
        if len(compare_parameter_results) > 30:
            compare_parameter_results = 'multiple sfiles'
    else:
        first_scan_parameter = None 

        for i, sfilename in enumerate(sfilename_list):
            scan_data, scan_parameter, scan = load_scan_data(
                top_dir, sfilename,
                search_replace_filename=search_replace_filename,
                column_math_filename=column_math_filename
            )

            if i == 0:
                first_scan_parameter = scan_parameter  # Store the first scan parameter
            else:
                if scan_parameter != first_scan_parameter:
                    print(f"Warning: Scan parameter in {os.path.basename(sfilename)} differs from the first scan parameter.")

            results.append(process_parameter_vs_scan_parameter(scan_data, scan_parameter, parameter, analyzer_dict))

            if compare_parameter is None:
                compare_parameter_results.append( os.path.basename(sfilename) )
            else:
                compare_parameter_results.append( np.nanmean(scan_data[compare_parameter]) )
                
    if manual_scan_parameter is not None:
        scan_parameter = manual_scan_parameter

    return results, compare_parameter_results, scan_parameter


   
def display_multi_scan_scalar_parameter(top_dir, results, parameter, scan_parameter, compare_parameter, compare_parameter_results,
                                display_dict={},
                                       ):
    
    fig, ax = plt.subplots(constrained_layout=True, figsize=display_dict.get('fig_size', (7,3) ))
    for i in range(len(results)):
        p_av, p_neg, p_pos, xp_av, xp_neg, xp_pos = results[i]

        if len(results) == 1:
            label = None
            auto_title = r'%s - %s - %s' %(top_dir, compare_parameter_results, display_dict.get('title_append', ''))
        else:
            label = 'multiple sfiles'
            # label = '%g' %compare_parameter_results[i]
            auto_title = r'%s - %s' %(top_dir, display_dict.get('title_append', ''))

        ax.errorbar(xp_av, p_av, yerr=(p_neg,p_pos), 
                   capsize=5, marker='o', markersize=4, ls='',
                   label=label,
                   )

        if display_dict.get('every_point', False):
            ax.scatter(scan_data[scan_parameter], scan_data[parameter], alpha=0.2)

    ax.set_xlabel(scan_parameter)
    ax.set_ylabel(parameter)
    
    legend_title = None
    if display_dict.get('legend_display_title', False):
        legend_title = display_dict.get('manual_legend_title', compare_parameter)

    if display_dict.get('add_legend', True):
        ax.legend(loc=display_dict.get('legend_location', 'best'),
                  ncol=display_dict.get('legend_ncol', 1),
                  title=legend_title)

    for v_line in display_dict.get('v_lines', []):
        ax.axvline(x=v_line, color='k', linestyle='--')

    for h_line in display_dict.get('h_lines', []):
        ax.axhline(y=h_line, color='k', linestyle='--')
    
    ax.set_title(display_dict.get('manual_title', auto_title ))
        
    return fig, ax
    
    
def check_list_contents(lst):
    if isinstance(lst, str):
        return 'single string'
    elif isinstance(lst, (list, np.ndarray)):
        if all(isinstance(item, str) for item in lst):
            return 'list of strings'
        elif all(isinstance(item, (int, float, np.integer, np.floating)) for item in lst):
            return 'list of numbers'
        else:
            return 'mixed types in list'
    else:
        return 'unexpected type'



def check_sfilename_list_contents(top_dir, sfilename_list):
    if check_list_contents(sfilename_list) == 'list of numbers':
        new_sfilename_list = []
        for scan in sfilename_list:
            new_sfilename_list.append( pygc.get_sfilename_from_top_dir(top_dir, scan, print_data=False) )
        return new_sfilename_list
    else:
        return sfilename_list

    
def set_scan_parameter(scan_data, manual_scan_parameter, rebin_data=True, method='zscore', zscore_thresh=1, rounding_factor=1):
    scan_parameter = manual_scan_parameter
    if rebin_data:
        scan_data = bin_data.bin_scan_data(scan_data, manual_scan_parameter, method=method, zscore_thresh=zscore_thresh, rounding_factor=rounding_factor)
    scan = scan_data['scan'][0]
    return scan_data, scan_parameter, scan
    
#####$
    

def write_binary(data, bin_filepath, nan_value=0):
    """
    Write a 2D NumPy array to a binary PNG image and create a scaling information text file.
    
    Parameters:
    - data (numpy.ndarray): The input 2D array to be saved.
    - bin_filepath (str): The base file path for the PNG image and scaling text file.
    - nan_value (float, optional): The scalar value to replace NaN values with. Default is 0.
    
    Returns:
    - None
    
    The function scales the input data to fit within a 16-bit range (0-65535) and saves it as a binary PNG image. 
    The scaling factors (min and max) used for scaling are saved in a text file with the same name.
    """
    
    # Replace NaN values with the specified scalar
    data = np.nan_to_num(data, nan=nan_value)

    # Calculate the scaling factors
    data_int = (65535 * ((data - np.min(data)) / np.ptp(data))).astype(np.uint16)

    # Create scaling information lines
    lines = ['[Scaling]', 'min = %f' % np.min(data), 'max = %f' % np.max(data)]

    # Write scaling information to a text file
    with open(bin_filepath + '.txt', 'w') as f:
        f.write('\n'.join(lines))

    # Save the scaled data as a binary PNG image
    imio.imwrite(bin_filepath + '.png', data_int)
    
# add columns to masterlog

def append_to_add_columns_df(scan, shot, return_dict, add_columns_df):
    # Create a new dictionary with scan and shot as the first two columns
    data = {'scan': scan, 'Shotnumber': shot}
    data.update(return_dict)  # Add the return_dict entries

    # If DataFrame is None, initialize it with the first row
    if add_columns_df is None:
        add_columns_df = pd.DataFrame([data])
    else:
        # Append the new data as a row
        add_columns_df = pd.concat([add_columns_df, pd.DataFrame([data])], ignore_index=True)
    return add_columns_df



def merge_data_frame_to_sfile(sfilename, add_columns_df, 
                              overwrite_columns=True, 
                              diagnostic=None, 
                              append_text=None, 
                              print_data=True):
    # Load the original data from the sfile
    sfile_data = pd.read_csv(sfilename, sep='\t')
    
    # Filter out any non-numeric columns in add_columns_df
    add_columns_df = add_columns_df.select_dtypes(include=['float64', 'int64', 'bool'])

    # Apply renaming to add_columns_df, excluding 'scan' and 'Shotnumber'
    if diagnostic or append_text:
        def rename_columns(col):
            if col in ['scan', 'Shotnumber']:
                return col  # Do not rename 'scan' or 'Shotnumber'
            new_col = col
            if diagnostic:
                new_col = f"{diagnostic} {new_col}"
            if append_text:
                new_col = f"{new_col} {append_text}"
            return new_col

        add_columns_df = add_columns_df.rename(columns=rename_columns)

    if overwrite_columns:
        # Drop the overlapping columns from sfile_data so they can be overwritten
        sfile_data = sfile_data.drop(columns=[col for col in add_columns_df.columns 
                                              if col in sfile_data.columns and col not in ['scan', 'Shotnumber']])
        # Merge to overwrite columns
        merged_df = pd.merge(sfile_data, add_columns_df, on=['scan', 'Shotnumber'], how='left')
    else:
        # Use suffixes to avoid column conflicts
        merged_df = pd.merge(sfile_data, add_columns_df, on=['scan', 'Shotnumber'], how='left', suffixes=('', '_2'))

        # Rename columns with incremental suffixes if needed
        col_rename = {}
        for col in merged_df.columns:
            if col.endswith('_2'):
                base_name = col[:-2]
                # Ensure unique naming by counting existing occurrences
                suffix_num = sum(base_name in c for c in merged_df.columns) - 1
                new_name = f"{base_name}_{suffix_num}"
                col_rename[col] = new_name

        # Apply the renaming to avoid conflicts
        merged_df = merged_df.rename(columns=col_rename)

    # Save the merged data back to the sfile
    merged_df.to_csv(sfilename, index=False, sep='\t')

    # Optionally print a message
    if print_data:
        print(f'Columns added to {sfilename}')
        
    return add_columns_df





def scan_analyzer(top_dir, scan_data, diagnostic, analyzer, 
                  analyzer_dict={}, 
                  display_dict={}, 
                  analysis_diagnostic=None, 
                  bg=None, 
                  write_analyzed_file_ext='.png', 
                 ):
    """
    Processes scan data with analysis and optional display and file writing.

    Parameters:
        scan_data (DataFrame): The scan data containing information like scan number, shot number, and file list.
        analyzer (object): Analyzer object with load_data, analyze_data, write_analyzed_data, and display_data methods.
        analyzer_dict (dict): Dictionary containing analysis settings and parameters.
        display_dict (dict): Dictionary containing display settings.
        top_dir (str): The top directory path for saving and retrieving data.
        diagnostic (str): Diagnostic name used for constructing filenames.
        analysis_diagnostic (str): Specific diagnostic for analysis.
        bg (optional): Background data or parameters for the analysis.
        file_ext (str, optional): File extension for saved files. Defaults to '.png'.

    Returns:
        None
    """

    add_columns_df = None
    
    for i in range(len(scan_data)):
        scan = int(scan_data['scan'][i])
        shot_num = int(scan_data['Shotnumber'][i])    
        analysis_dir = get_analysis_dir(top_dir, scan, save_label=None, make_dir=True, print_data=False)
        filename = scan_data['%s file_list' % diagnostic][i]    

        data = analyzer.load_data(filename)
        data, return_dict = analyzer.analyze_data(data, analyzer_dict, bg=bg)

        # Append to add_columns_df if required
        if analyzer_dict.get('add_columns_to_masterlog', False):
            add_columns_df = append_to_add_columns_df(scan, shot_num, return_dict, add_columns_df)

        # Save analyzed data if required
        if analyzer_dict.get('write_analyzed', False):
            save_path = get_analysed_shot_save_path(analysis_dir, 
                                                         analysis_diagnostic, 
                                                         scan, 
                                                         shot_num, 
                                                         file_ext=write_analyzed_file_ext
                                                        )
            analyzer.write_analyzed_data(save_path, data)

        # Display data if required
        if display_dict.get('display_data', False):
            fig, ax = analyzer.display_data(data, display_dict, title=os.path.basename(filename))

    if analyzer_dict.get('write_controls', False) and len(scan_data) > 0:
        controls_path = os.path.join(analysis_dir, '%s analyzer_controls %s.txt' % (diagnostic, analyzer_dict.get('append_text', '')))
        write_controls_from_python(controls_path, analyzer_dict)
        
    return add_columns_df


def generate_list_of_data(top_dir, sfilename, diagnostic, file_ext, analyzer, search_replace_filename=None, column_math_filename=None):
    scan_data, scan_parameter, scan = load_scan_data(top_dir, sfilename, 
                                                          search_replace_filename=search_replace_filename, 
                                                          column_math_filename=column_math_filename,
                                                          diagnostic=diagnostic,
                                                          file_ext=file_ext
                                                         )

    list_of_data = []
    for i in range(len(scan_data)):
        filename = scan_data['%s file_list' %diagnostic][i]  
        list_of_data.append( analyzer.load_data(filename) )
    return scan_data, list_of_data


def generate_averaged_background(sfilename, diagnostic, file_ext, analyzer, search_replace_filename=None, column_math_filename=None, write_bg=True):
    top_dir, year, month, day = get_top_dir_from_sfilename(sfilename, print_data=False)
    scan_data, list_of_data = generate_list_of_data(top_dir, sfilename, diagnostic, file_ext, analyzer, 
                                                    search_replace_filename=search_replace_filename, 
                                                    column_math_filename=column_math_filename)
    if len(scan_data) > 0:
        scan = scan_data['scan'][0]
        mean_data, std_data = analyzer.average_data_list(list_of_data)
        
        bg_path = os.path.join(top_dir, 'analysis', 'Scan%03d%s_averaged%s' % (scan, diagnostic, file_ext))
        if write_bg and not os.path.exists(bg_path):
            analyzer.write_analyzed_data(bg_path, mean_data)
    else:
        print('No data in scan, no bg saved.')
    return scan_data, mean_data, std_data


import PyGEECSPlotter.plotting as gplt
colors = gplt.configure_plotting()
